<?php 
require 'functions.php';
$keyword = $_GET['keyword'];
	$query_cari = "SELECT * FROM mahasiswa WHERE 
					nrp LIKE '%$keyword%' OR
					nama LIKE '%$keyword%' OR
					email LIKE '%$keyword%' OR
					jurusan LIKE '%$keyword%'
					";
	$mahasiswa = query($query_cari);
 ?>
 <table border="1" cellspacing="0" cellpadding="10">
		<tr>
			<th>No.</th>
			<th>NRP</th>
			<th>Nama</th>
			<th>Email</th>
			<th>Jurusan</th>
			<th>Aksi</th>
		</tr>

		<?php if( empty($mahasiswa) ) : ?>
			<tr>
				<td colspan="6" align="center">DATA TIDAK DITEMUKAN</td>
			</tr>
		<?php endif; ?>

		<?php $i = 1; ?>
		<?php foreach($mahasiswa as $mhs ) : ?>
		<tr>
			<td><?= $i++; ?></td>
			<td><?= $mhs['nrp']; ?></td>
			<td><?= $mhs['nama']; ?></td>
			<td><?= $mhs['email']; ?></td>
			<td><?= $mhs['jurusan']; ?></td>
			<td>
				<a href="ubah.php?id=<?= $mhs['id']; ?>">ubah</a> | 
				<a href="hapus.php?id=<?= $mhs['id']; ?>" onclick="return confirm('yakin brother ?');">hapus</a>
			</td>
		</tr>
		<?php endforeach; ?>	
	</table>