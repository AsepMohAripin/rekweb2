<?php 
$conn = mysqli_connect('localhost', 'root', '', 'pw_183040118');

function query($query) {
	global $conn;
	$result = mysqli_query($conn, $query);

	$rows = [];
	while($row = mysqli_fetch_assoc($result)){
		$rows[] = $row;
	}

	return $rows;
}

function tambah($data) {
	global $conn;

	$nrp =htmlspecialchars($data['nrp']); 
	$nama =htmlspecialchars($data['nama']);
	$email =htmlspecialchars($data['email']);
	$jurusan =htmlspecialchars($data['jurusan']);

	$query = "INSERT INTO mahasiswa
			VAlUES
			('', '$nrp', '$nama', '$email', '$jurusan')";

	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);

}

function hapus($id){
	global $conn;
	mysqli_query($conn, "DELETE FROM mahasiswa WHERE id = $id");

	return mysqli_affected_rows($conn);
}

function ubah($data) {
	global $conn;
	$id = $data['id'];
	$nrp =htmlspecialchars($data['nrp']); 
	$nama =htmlspecialchars($data['nama']);
	$email =htmlspecialchars($data['email']);
	$jurusan =htmlspecialchars($data['jurusan']);

	$query = "UPDATE mahasiswa SET 
				nrp = '$nrp',
				nama = '$nama',
				email = '$email',
				jurusan = '$jurusan'
				WHERE id = $id
				";

	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);

}


function registrasi($data){
	global $conn;
	$username = $data['username'];
	$password1 = $data['password1'];
	$password2 = $data['password2'];

	// cek user
	$cek_user = mysqli_query($conn, "SELECT * FROM user WHERE username = '$username'");

	if(mysqli_num_rows($cek_user) > 0){
		echo "<script>
				alert('username sudah terdaftar');
				document.location.href='registrasi.php';
			  </script>";
			  return false;
	}
	//password1 tidaksama dengan password2
	if( $password1 != $password2){
		echo "<script>
				alert('konfirmasi tidak sesuai');
				document.location.href='registrasi.php';
			  </script>";
		return false;
	} 



	// username dan password sudah OK
	$password = password_hash($password1, PASSWORD_DEFAULT);

	$query = "INSERT INTO user VAlUES
				('', '$username', '$password')";
	mysqli_query($conn, $query);


	return mysqli_affected_rows($conn);

}






 ?>