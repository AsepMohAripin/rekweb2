<?php
session_start();

if ( !isset($_SESSION['username']) ){
	header("Location: login.php");
	exit;
}


require 'functions.php';
$mahasiswa = query("SELECT * FROM mahasiswa");

if( isset($_GET['cari']) ){
	$keyword = $_GET['keyword'];
	$query_cari = "SELECT * FROM mahasiswa WHERE 
					nrp LIKE '%$keyword%' OR
					nama LIKE '%$keyword%' OR
					email LIKE '%$keyword%' OR
					jurusan LIKE '%$keyword%'
					";
	$mahasiswa = query($query_cari);
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Daftar Mahasiswa</title>
</head>
<body>
	<a href="logout.php">LOGOUT</a>



	<h3>Daftar Mahasiswa</h3>

	<a href="tambah.php">Tambah Data Mahasiswa</a>
	<br><br>

	<form action="" method="get">
		<input type="text" name="keyword" id="keyword">
		<button type="submit" name="cari" id="tombol">CARI</button>
	</form>
	<br>

	<div id="container">
	<table border="1" cellspacing="0" cellpadding="10">
		<tr>
			<th>No.</th>
			<th>NRP</th>
			<th>Nama</th>
			<th>Email</th>
			<th>Jurusan</th>
			<th>Aksi</th>
		</tr>

		<?php if( empty($mahasiswa) ) : ?>
			<tr>
				<td colspan="6" align="center">DATA TIDAK DITEMUKAN</td>
			</tr>
		<?php endif; ?>

		<?php $i = 1; ?>
		<?php foreach($mahasiswa as $mhs ) : ?>
		<tr>
			<td><?= $i++; ?></td>
			<td><?= $mhs['nrp']; ?></td>
			<td><?= $mhs['nama']; ?></td>
			<td><?= $mhs['email']; ?></td>
			<td><?= $mhs['jurusan']; ?></td>
			<td>
				<a href="ubah.php?id=<?= $mhs['id']; ?>">ubah</a> | 
				<a href="hapus.php?id=<?= $mhs['id']; ?>" onclick="return confirm('yakin brother ?');">hapus</a>
			</td>
		</tr>
		<?php endforeach; ?>	
	</table>
	</div>


<script type="text/javascript" src="script.js"></script>
</body>
</html>