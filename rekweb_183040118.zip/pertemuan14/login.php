<?php 
session_start();
if( isset($_SESSION['username']) ){
	header("Location: index.php");
	exit;
}

require 'functions.php';

if( isset($_POST['login']) ){
	$username = $_POST['username'];
	$password = $_POST['password'];

	$cek_user = mysqli_query($conn, "SELECT * FROM user WHERE username = '$username'");

	if( mysqli_num_rows($cek_user) == 1 ){


		$user = mysqli_fetch_assoc($cek_user);
		if( password_verify($password, $user['password'])){
			// logim berhasil masuk ke index
			$_SESSION['username'] = $username;
			header('location: index.php');
			exit;
		}else {
			$error = 'password na salah cuk';
		}

	}else {
		// login gagal
		$error = 'username na salah cuk';
	}
}



 ?>
<!DOCTYPE html>
<html>
<head>
	<title>LOGIN</title>
</head>
<body>

<h2>LOGIN</h2>
<?php if( isset($error)) : ?>
	<p><?= $error ?></p>
<?php endif; ?>

<form action="" method="post">
	<ul>
		<li>
			<label>Username :</label><br>
			<input type="text" name="username">
		</li>
		<li>
			<label>Password :</label><br>
			<input type="password" name="password">
		</li>
		<li>
			<button type="submit" name="login">LOGIN</button>
		</li>
	</ul>
</form>
<a href="registrasi.php">Registrasi</a>









</body>
</html>